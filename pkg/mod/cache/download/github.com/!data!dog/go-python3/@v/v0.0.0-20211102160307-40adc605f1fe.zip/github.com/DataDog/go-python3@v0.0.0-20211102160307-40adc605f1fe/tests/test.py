from io import StringIO
import sys

sys.stdout = StringIO()


print("hello world")